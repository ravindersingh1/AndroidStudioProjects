package com.example.ravinder.arttherapy;

/**
 * Created by Ravinder on 2/14/15.
 */
public class Point {
    float x, y;

}
